// بانرات SHADOW BACK
// - لو في banner.json فيه "base": الصور بتتحمّل من النت (زي ما كان في البوت)
// - لو مفيش: بتتحمّل من الموبايل نفسه
import fs from 'node:fs';
import http from 'node:http';
import { fileURLToPath } from 'node:url';

const DIR = fileURLToPath(new URL('../assets/banners/', import.meta.url));
const CFG = fileURLToPath(new URL('../banner.json', import.meta.url));
const PORT = 8099;
const cache = {};

let BASE = process.env.BANNER_BASE || null;
if (!BASE) {
  try { BASE = JSON.parse(fs.readFileSync(CFG, 'utf8')).base || null; } catch {}
}
if (BASE) BASE = String(BASE).trim().replace(/\/+$/, '');

export const banner = (name) => (cache[name] ??= fs.readFileSync(DIR + name + '.jpg'));

export const bannerUrl = (name) => (BASE ? `${BASE}/${name}.jpg` : `http://127.0.0.1:${PORT}/${name}.jpg`);

export const sendBanner = (conn, chat, name, caption, { quoted, contextInfo } = {}) => {
  if (BASE) {
    return conn.linkPreview(
      chat,
      {
        text: caption,
        url: bannerUrl(name),
        height: 438,
        width: 734,
        title: 'ꜱʜᴀᴅᴏᴡ ʙᴀᴄᴋ',
        description: 'SHADOW BACK BOT',
        contextInfo,
      },
      quoted ? { quoted } : undefined
    );
  }
  return conn.sendMessage(chat, { image: banner(name), caption, contextInfo }, quoted ? { quoted } : {});
};

// سيرفر محلي بيشتغل بس لو مفيش رابط نت
if (!BASE && !globalThis.__bannerServer) {
  globalThis.__bannerServer = true;
  const srv = http.createServer((req, res) => {
    const name = (req.url || '').split('?')[0].replace(/^\//, '').replace(/\.jpg$/, '');
    if (!/^[a-z]+$/.test(name) || !fs.existsSync(DIR + name + '.jpg')) {
      res.statusCode = 404;
      return res.end();
    }
    res.setHeader('content-type', 'image/jpeg');
    res.end(banner(name));
  });
  srv.on('error', (e) => console.error('[banner] server error:', e.message));
  srv.listen(PORT, '127.0.0.1');
  srv.unref();
}
