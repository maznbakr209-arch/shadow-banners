import { sendBanner, bannerUrl } from '../../system/banner.js';
const fff = async (m, { conn, text,}) => {
await sendBanner(conn, m.chat, 'main', `𝐑𝐞𝐳𝐞 𝐛𝐨𝐭 𝐜𝐨𝐧𝐧𝐞𝐜𝐭𝐞𝐝 🪻`, { quoted: m });
};
fff.usage = ["تست"]
fff.command = ["تست"];
fff.prefixe = false;
fff.category = "group";
export default fff;