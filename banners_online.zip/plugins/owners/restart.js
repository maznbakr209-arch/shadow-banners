import { sendBanner, bannerUrl } from '../../system/banner.js';
import process from "node:process";
const restart = async (m, { conn }) => {
  m.react("⏳");
await   sendBanner(conn, m.chat, 'restart', "جاري إعادة تشغيل البوت...", { quoted: m });
  process.exit(1);
};

restart.usage = ["ريستارت"]
restart.command = ["ريستارت", "restart"];
restart.owner = true;
restart.category = "owners";
export default restart;
