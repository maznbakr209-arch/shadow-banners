import { sendBanner, bannerUrl } from '../../system/banner.js';
const handler = async (m, { conn, cli }) => {
  const start = process.hrtime.bigint();
  await conn.sendMessage(m.chat, { text: "🏓 msg test" });
  const end = process.hrtime.bigint();
  const ping = Number(end - start) / 1e6;

  const msg =
    `*⪩ سـرعـة الـبـوت ↯ •*\n` +
    `── ⋅ ⋅ ── 🪻 ── ⋅ ⋅ ── \n\n` +
    `⦑ ⚡ ⦒ ⦂ الاسـتـجـابـة ↜ ⟦ ${ping.toFixed(2)}ms ⟧\n\n` +
    `── ⋅ ⋅ ── 🪻 ── ⋅ ⋅ ── \n` +
    `> ⦂ 𝐫𝐞𝐳𝐞 ↚ 𝐛𝐲 : ꜱʜᴀᴅᴏᴡ ʙᴀᴄᴋ ╷`;

  await sendBanner(conn, m.chat, 'ping', msg, { quoted: m, contextInfo: cli?.config?.info?.channel });
};

handler.command = ["بنج", "ping"];
handler.category = "info";
handler.usage = ["بنج"];
export default handler;